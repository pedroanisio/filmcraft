# includes

package `includes` 1.0.0 · 320×180 · 24 fps · 1 s

This is a scene video package (format `scene-video-package` 1.1). `vpkg.json` lists every file with its SHA-256, the scenes, the pipeline that rebuilds the video, and what must be installed or downloaded. Only the render engine is not included.

## Use

```bash
scenerender-vpkg verify includes-1.0.0.vpkg.zip
scenerender-vpkg unpack includes-1.0.0.vpkg.zip includes --fetch
scenerender-vpkg run includes --engine py        # or rs, c, js; --list shows the plan
```

Without the tool: unzip, download each `fetch` entry to its path (check the SHA-256), set `FONTCONFIG_FILE=project/_vpkg/fonts.conf` when present, and run the steps below from `project/`.

## Scenes

- `main.scene` — primary

## Contents

| Role | Files | Size |
|---|---:|---:|
| asset | 1 | 12 B |
| include | 1 | 49 B |
| scene | 1 | 134 B |
| **total** | 3 | 195 B |
