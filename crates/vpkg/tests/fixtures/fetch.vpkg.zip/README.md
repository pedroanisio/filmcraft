# fetch

package `fetch` 1.0.0 · 320×180 · 24 fps · 1 s

This is a scene video package (format `scene-video-package` 1.1). `vpkg.json` lists every file with its SHA-256, the scenes, the pipeline that rebuilds the video, and what must be installed or downloaded. Only the render engine is not included.

## Use

```bash
scenerender-vpkg verify fetch-1.0.0.vpkg.zip
scenerender-vpkg unpack fetch-1.0.0.vpkg.zip fetch --fetch
scenerender-vpkg run fetch --engine py        # or rs, c, js; --list shows the plan
```

Without the tool: unzip, download each `fetch` entry to its path (check the SHA-256), set `FONTCONFIG_FILE=project/_vpkg/fonts.conf` when present, and run the steps below from `project/`.

## Scenes

- `main.scene` — primary

## Pipeline

Run from `project/`. Steps marked optional need a tool or network access that may be missing; their outputs are already in the package.

1. **frames** (command): `generate`

## Downloads

| Path | Size | Source |
|---|---|---|
| `download.json` | 2 B | https://example.org/download.json |

## Contents

| Role | Files | Size |
|---|---:|---:|
| scene | 1 | 192 B |
| **total** | 1 | 192 B |
