# minimal

package `minimal` 1.0.0 · 320×180 · 24 fps · 1 s

This is a scene video package (format `scene-video-package` 1.1). `vpkg.json` lists every file with its SHA-256, the scenes, the pipeline that rebuilds the video, and what must be installed or downloaded. Only the render engine is not included.

## Use

```bash
scenerender-vpkg verify minimal-1.0.0.vpkg.zip
scenerender-vpkg unpack minimal-1.0.0.vpkg.zip minimal --fetch
scenerender-vpkg run minimal --engine py        # or rs, c, js; --list shows the plan
```

Without the tool: unzip, download each `fetch` entry to its path (check the SHA-256), set `FONTCONFIG_FILE=project/_vpkg/fonts.conf` when present, and run the steps below from `project/`.

## Scenes

- `main.scene` — primary

## Contents

| Role | Files | Size |
|---|---:|---:|
| scene | 1 | 100 B |
| **total** | 1 | 100 B |
